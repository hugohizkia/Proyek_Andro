package com.example.project_andro

data class dataSaran(
    var id : String ,
    var saran : String
)
