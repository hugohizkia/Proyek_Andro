package com.example.project_andro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore

class SignUp : AppCompatActivity() {
    lateinit var NamaD: EditText
    lateinit var NamaB: EditText
    lateinit var NoTelp: EditText
    lateinit var Email: EditText
    lateinit var Password: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        val _signup = findViewById<Button>(R.id.btn_signup)

        val db = FirebaseFirestore.getInstance()
        NamaD = findViewById<EditText>(R.id.NamaDepanET)
        NamaB = findViewById<EditText>(R.id.NamaBelakangET)
        NoTelp = findViewById<EditText>(R.id.NoTelpET)
        Email = findViewById<EditText>(R.id.EmailET)
        Password = findViewById<EditText>(R.id.PasswordET)

        _signup.setOnClickListener {
            TambahData(db, NamaD.text.toString(), NamaB.text.toString(), NoTelp.text.toString(), Email.text.toString(),Password.text.toString())
        }
    }

    fun TambahData(db: FirebaseFirestore, namaDepan: String, namaBelakang: String, notelp: String, email: String, password:String){

        var cek = 1
        if (cek == 1){
            db.collection("dbUser").get().addOnSuccessListener { result ->
                for (document in result){
                    if (email == document.data.get("email")){
                        Toast.makeText(this@SignUp , "Maaf email yang dimasukan sudah terpakai" , Toast.LENGTH_LONG).show()
                        cek = 2
                    }
                }
                if (cek != 2){
                    val namaBaru = datalogin(namaDepan, namaBelakang, notelp, email, password)
                    db.collection("dbUser").document(email).set(namaBaru).addOnSuccessListener {
                        NamaD.setText("")
                        NamaB.setText("")
                        NoTelp.setText("")
                        Email.setText("")
                        Password.setText("")
                        Log.d("firebase22", "Simpan data berhasil")
                        val eIntent = Intent(this@SignUp, LoginPage::class.java)
                        startActivity(eIntent)
                    }.addOnFailureListener {
                        Log.d("firebase22", it.message.toString())

                    }
                }
            }
        }
    }
}