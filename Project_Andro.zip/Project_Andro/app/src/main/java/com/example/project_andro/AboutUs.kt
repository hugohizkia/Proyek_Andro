package com.example.project_andro

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.firestore.FirebaseFirestore

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


/**
 * A simple [Fragment] subclass.
 * Use the [AboutUs.newInstance] factory method to
 * create an instance of this fragment.
 */
class AboutUs : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val db = FirebaseFirestore.getInstance()

        var id = "1"
        var cek = 0
        var hasil = 0
        var int_id = 0
        var _saran = view.findViewById<EditText>(R.id.saran)
        var _sent = view.findViewById<FloatingActionButton>(R.id.sent_btn)

        db.collection("dbSaran").get().addOnSuccessListener { result ->
            for (document in result){
                id = document.data.get("id").toString()

                int_id = id.toInt()+1
                if (cek < int_id){
                    if (hasil < int_id){
                        hasil = int_id
                    }

                }
                else if (cek > int_id){
                    cek = cek + 1
                    if (hasil < cek){
                        hasil = cek
                    }
                }
                cek = id.toInt()
                id = hasil.toString()
            }
        }
        _sent.setOnClickListener {
            db.collection("dbSaran").get().addOnSuccessListener { result ->
                for (document in result){
                    id = document.data.get("id").toString()

                    int_id = id.toInt()+1
                    if (cek < int_id){
                        if (hasil < int_id){
                            hasil = int_id
                        }

                    }
                    else if (cek > int_id){
                        cek = cek + 1
                        if (hasil < cek){
                            hasil = cek
                        }
                    }
                    cek = id.toInt()
                    id = hasil.toString()
                }
            }

            val saranBaru = dataSaran(id, _saran.text.toString())
            db.collection("dbSaran").document(id).set(saranBaru).addOnSuccessListener {
                _saran.setText("")
                Log.d("firebase22", "Simpan data berhasil")
            }.addOnFailureListener {
                Log.d("firebase22", it.message.toString())
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_about_us, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment AboutUs.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            AboutUs().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}