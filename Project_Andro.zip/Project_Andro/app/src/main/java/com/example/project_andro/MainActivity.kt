package com.example.project_andro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer

class MainActivity : AppCompatActivity() {
    private lateinit var timer: CountDownTimer
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        timer = object : CountDownTimer(2500 , 1000){
            override fun onTick(p0: Long) {
                print("Not Done")
            }

            override fun onFinish() {
                print("Done")
                val sendIntent = Intent(this@MainActivity, LoginPage::class.java).apply {

                }
                startActivity(sendIntent)
            }
        }
    }
    override fun onStart() {
        super.onStart()
        timer.start()
    }

    override fun onStop() {
        super.onStop()
        timer.cancel()
    }
}