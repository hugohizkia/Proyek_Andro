package com.example.project_andro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.firebase.firestore.FirebaseFirestore

class ConfirmDeleteAcc : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm_delete_acc)

        val data1= intent.getStringExtra("data1")

        var _btnyes = findViewById<Button>(R.id.btn_yes)
        var _btnno = findViewById<Button>(R.id.btn_no)

        val db = FirebaseFirestore.getInstance()

        _btnyes.setOnClickListener {
            var count = 1
            if (count == 1){
                db.collection("dbReservasi").get().addOnSuccessListener { result ->
                    for (document in result){
                        if (data1.toString() == document.data.get("email")){
                            db.collection("dbReservasi").document(document.data.get("id_meja").toString()).delete()
                        }
                    }
                }
                db.collection("dbUser").document(data1.toString()).delete()
                val sendIntent = Intent(this@ConfirmDeleteAcc, LoginPage::class.java).apply {
                    putExtra("dataEmail", data1)
                }
                startActivity(sendIntent)
            }

        }

        _btnno.setOnClickListener {
            val sendIntent = Intent(this@ConfirmDeleteAcc, MainActivity2::class.java).apply {
                putExtra("data_no", "no1")
                putExtra("dataEmail", data1)
            }
            startActivity(sendIntent)
        }
    }
}