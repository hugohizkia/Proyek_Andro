package com.example.project_andro

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.google.firebase.firestore.FirebaseFirestore

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [Lunch.newInstance] factory method to
 * create an instance of this fragment.
 */
class Lunch : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        var i1 = 0
        var i2 = 0
        var i3 = 0
        var i4 = 0
        var i5 = 0
        var i6 = 0
        var i7 = 0
        var i8 = 0
        var i9 = 0
        var i10 = 0
        var i11 = 0
        var i12 = 0
        var i13 = 0
        var i14 = 0
        var i15 = 0
        var i16 = 0
        var i17 = 0
        var i18 = 0
        var i19 = 0
        var i20 = 0
        var i21 = 0
        var i22 = 0
        var i23 = 0
        var i24 = 0
        var i25 = 0
        var i26 = 0
        var i27 = 0

        val list = mutableListOf("meja1","meja2","meja3","meja4","meja5","meja6","meja7","meja8","meja9","meja10","meja11","meja12","meja13","meja14","meja15"
            ,"meja16","meja17","meja18","meja19","meja20","meja21","meja22","meja23","meja24","meja25","meja26","meja27")

        val Temp = arguments?.getString("data").toString()
        val Temp1 = arguments?.getString("data1").toString()
        val db = FirebaseFirestore.getInstance()
        var temp_id_table = ""
        var M1 = view.findViewById<ImageView>(R.id.meja1)
        var M2 = view.findViewById<ImageView>(R.id.meja2)
        var M3 = view.findViewById<ImageView>(R.id.meja3)
        var M4 = view.findViewById<ImageView>(R.id.meja4)
        var M5 = view.findViewById<ImageView>(R.id.meja5)
        var M6 = view.findViewById<ImageView>(R.id.meja6)
        var M7 = view.findViewById<ImageView>(R.id.meja7)
        var M8 = view.findViewById<ImageView>(R.id.meja8)
        var M9 = view.findViewById<ImageView>(R.id.meja9)
        var M10 = view.findViewById<ImageView>(R.id.meja10)
        var M11 = view.findViewById<ImageView>(R.id.meja11)
        var M12 = view.findViewById<ImageView>(R.id.meja12)
        var M13 = view.findViewById<ImageView>(R.id.meja13)
        var M14 = view.findViewById<ImageView>(R.id.meja14)
        var M15 = view.findViewById<ImageView>(R.id.meja15)
        var M16 = view.findViewById<ImageView>(R.id.meja16)
        var M17 = view.findViewById<ImageView>(R.id.meja17)
        var M18 = view.findViewById<ImageView>(R.id.meja18)
        var M19 = view.findViewById<ImageView>(R.id.meja19)
        var M20 = view.findViewById<ImageView>(R.id.meja20)
        var M21 = view.findViewById<ImageView>(R.id.meja21)
        var M22 = view.findViewById<ImageView>(R.id.meja22)
        var M23 = view.findViewById<ImageView>(R.id.meja23)
        var M24 = view.findViewById<ImageView>(R.id.meja24)
        var M25 = view.findViewById<ImageView>(R.id.meja25)
        var M26 = view.findViewById<ImageView>(R.id.meja26)
        var M27 = view.findViewById<ImageView>(R.id.meja27)

        db.collection("dbLunch").get().addOnSuccessListener { result ->
            for (document in result){
                temp_id_table = document.data.get("id_meja") as String
                if(document.data.get("tanggal") == Temp1){
                    for (j in list){
                        if (temp_id_table == j){
                            if (temp_id_table == "meja1"){
                                M1.setImageResource(R.drawable.mejabundar_nav)
                                i1 = 1
                                if (Temp == document.data.get("email")){
                                    i1 = 2
                                }
                            }

                            else if (temp_id_table == "meja2"){
                                M2.setImageResource(R.drawable.mejabundar_nav)
                                i2 = 1
                                if (Temp == document.data.get("email")){
                                    i2 = 2
                                }
                            }

                            else if (temp_id_table == "meja3"){
                                M3.setImageResource(R.drawable.mejabundar_nav)
                                i3 = 1
                                if (Temp == document.data.get("email")){
                                    i3 = 2
                                }
                            }

                            else if (temp_id_table == "meja4"){
                                M4.setImageResource(R.drawable.mejapanjang2_nav)
                                i4 = 1
                                if (Temp == document.data.get("email")){
                                    i4 = 2
                                }
                            }

                            else if (temp_id_table == "meja5"){
                                M5.setImageResource(R.drawable.mejapanjang_nav)
                                i5 = 1
                                if (Temp == document.data.get("email")){
                                    i5 = 2
                                }
                            }

                            else if (temp_id_table == "meja6"){
                                M6.setImageResource(R.drawable.mejapanjang2_nav)
                                i6 = 1
                                if (Temp == document.data.get("email")){
                                    i6 = 2
                                }
                            }

                            else if (temp_id_table == "meja7"){
                                M7.setImageResource(R.drawable.mejapanjang_nav)
                                i7 = 1
                                if (Temp == document.data.get("email")){
                                    i7 = 2
                                }
                            }

                            else if (temp_id_table == "meja8"){
                                M8.setImageResource(R.drawable.meja_notav)
                                i8 = 1
                                if (Temp == document.data.get("email")){
                                    i8 = 2
                                }
                            }

                            else if (temp_id_table == "meja9"){
                                M9.setImageResource(R.drawable.meja_notav)
                                i9 = 1
                                if (Temp == document.data.get("email")){
                                    i9 = 2
                                }
                            }

                            else if (temp_id_table == "meja10"){
                                M10.setImageResource(R.drawable.meja_notav)
                                i10 = 1
                                if (Temp == document.data.get("email")){
                                    i10 = 2
                                }
                            }

                            else if (temp_id_table == "meja11"){
                                M11.setImageResource(R.drawable.meja_notav)
                                i11 = 1
                                if (Temp == document.data.get("email")){
                                    i11 = 2
                                }
                            }

                            else if (temp_id_table == "meja12"){
                                M12.setImageResource(R.drawable.mejapanjang_nav)
                                i12 = 1
                                if (Temp == document.data.get("email")){
                                    i12 = 2
                                }
                            }

                            else if (temp_id_table == "meja13"){
                                M13.setImageResource(R.drawable.mejabundar_nav)
                                i13 = 1
                                if (Temp == document.data.get("email")){
                                    i13 = 2
                                }
                            }

                            else if (temp_id_table == "meja14"){
                                M14.setImageResource(R.drawable.mejabundar_nav)
                                i14 = 1
                                if (Temp == document.data.get("email")){
                                    i14 = 2
                                }
                            }

                            else if (temp_id_table == "meja15"){
                                M15.setImageResource(R.drawable.mejapanjang_nav)
                                i15 = 1
                                if (Temp == document.data.get("email")){
                                    i15 = 2
                                }
                            }

                            else if (temp_id_table == "meja16"){
                                M16.setImageResource(R.drawable.meja_notav)
                                i16 = 1
                                if (Temp == document.data.get("email")){
                                    i16 = 2
                                }
                            }

                            else if (temp_id_table == "meja17"){
                                M17.setImageResource(R.drawable.meja_notav)
                                i17 = 1
                                if (Temp == document.data.get("email")){
                                    i17 = 2
                                }
                            }

                            else if (temp_id_table == "meja18"){
                                M18.setImageResource(R.drawable.meja_notav)
                                i18 = 1
                                if (Temp == document.data.get("email")){
                                    i18 = 2
                                }
                            }

                            else if (temp_id_table == "meja19"){
                                M19.setImageResource(R.drawable.meja_notav)
                                i19 = 1
                                if (Temp == document.data.get("email")){
                                    i19 = 2
                                }
                            }

                            else if (temp_id_table == "meja20"){
                                M20.setImageResource(R.drawable.mejapanjang_nav)
                                i20 = 1
                                if (Temp == document.data.get("email")){
                                    i20 = 2
                                }
                            }

                            else if (temp_id_table == "meja21"){
                                M21.setImageResource(R.drawable.mejapanjang2_nav)
                                i21 = 1
                                if (Temp == document.data.get("email")){
                                    i21 = 2
                                }
                            }

                            else if (temp_id_table == "meja22"){
                                M22.setImageResource(R.drawable.mejapanjang_nav)
                                i22 = 1
                                if (Temp == document.data.get("email")){
                                    i22 = 2
                                }
                            }

                            else if (temp_id_table == "meja23"){
                                M23.setImageResource(R.drawable.mejapanjang2_nav)
                                i23 = 1
                                if (Temp == document.data.get("email")){
                                    i23 = 2
                                }
                            }

                            else if (temp_id_table == "meja24"){
                                M24.setImageResource(R.drawable.mejapanjang_nav)
                                i24 = 1
                                if (Temp == document.data.get("email")){
                                    i24 = 2
                                }
                            }

                            else if (temp_id_table == "meja25"){
                                M25.setImageResource(R.drawable.mejapanjang_nav)
                                i25 = 1
                                if (Temp == document.data.get("email")){
                                    i25 = 2
                                }
                            }

                            else if (temp_id_table == "meja26"){
                                M26.setImageResource(R.drawable.mejapanjang_nav)
                                i26 = 1
                                if (Temp == document.data.get("email")){
                                    i26 = 2
                                }
                            }

                            else if (temp_id_table == "meja27"){
                                M27.setImageResource(R.drawable.mejapanjang_nav)
                                i27 = 1
                                if (Temp == document.data.get("email")){
                                    i27 = 2
                                }
                            }

                        }
                    }
                }

            }
        }

        M1.setOnClickListener {
            if (i1 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(0))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i1 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(0))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M2.setOnClickListener {
            if (i2 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(1))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i2 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(1))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M3.setOnClickListener {
            if (i3 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(2))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i3 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(2))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M4.setOnClickListener {
            if (i4 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(3))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i4 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(3))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M5.setOnClickListener {
            if (i5 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(4))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i5 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(4))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M6.setOnClickListener {
            if (i6 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(5))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i6 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(5))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M7.setOnClickListener {
            if (i7 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(6))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i7 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(6))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M8.setOnClickListener {
            if (i8 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(7))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i8 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(7))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M9.setOnClickListener {
            if (i9 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(8))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i9 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(8))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M10.setOnClickListener {
            if (i10 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(9))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i10 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(9))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M11.setOnClickListener {
            if (i11 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(10))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i11 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(10))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M12.setOnClickListener {
            if (i12 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(11))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i12 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(11))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M13.setOnClickListener {
            if (i13 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(12))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i13 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(12))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M14.setOnClickListener {
            if (i14 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(13))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i14 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(13))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M15.setOnClickListener {
            if (i15 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(14))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i15 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(14))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M16.setOnClickListener {
            if (i16 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(15))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i16 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(15))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M17.setOnClickListener {
            if (i17 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(16))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i17 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(16))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M18.setOnClickListener {
            if (i18 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(17))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i18 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(17))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M19.setOnClickListener {
            if (i19 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(18))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i19 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(18))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M20.setOnClickListener {
            if (i20 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(19))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i20 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(19))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M21.setOnClickListener {
            if (i21 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(20))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i21 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(20))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M22.setOnClickListener {
            if (i22 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(21))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i22 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(21))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M23.setOnClickListener {
            if (i23 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(22))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i23 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(22))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M24.setOnClickListener {
            if (i23 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(22))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i23 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(22))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M25.setOnClickListener {
            if (i25 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(24))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i25 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(24))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M26.setOnClickListener {
            if (i26 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(25))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i26 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(25))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

        M27.setOnClickListener {
            if (i27 == 0){
                val intent = Intent (this@Lunch.requireContext() , ConfirmLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(26))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
            else if (i27 == 2) {
                val intent = Intent (this@Lunch.requireContext() , CancelLunch::class.java).apply {
                    putExtra("data1", Temp)
                    putExtra("data2", list.get(26))
                    putExtra("data3" , Temp1)
                }
                startActivity(intent)
            }
        }

    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_lunch, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Lunch.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Lunch().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}