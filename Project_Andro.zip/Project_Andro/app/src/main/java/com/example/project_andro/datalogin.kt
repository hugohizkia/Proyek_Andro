package com.example.project_andro

data class datalogin(
    var namad: String,
    var namab: String,
    var notelp: String,
    var email: String,
    var password: String
)
