package com.example.project_andro

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore

class LoginPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_page)

        val db = FirebaseFirestore.getInstance()
        val _login = findViewById<Button>(R.id.Login)
        val _signup = findViewById<Button>(R.id.L_btn_SI)
        val _email = findViewById<EditText>(R.id.email)
        val _password = findViewById<EditText>(R.id.password)



        _login.setOnClickListener {
//            val sendIntent = Intent(this@LoginPage, AdminActivity::class.java).apply {
//                putExtra("dataEmail", _email.text.toString())
//            }
//            startActivity(sendIntent)
            readData(db , _email.text.toString() , _password.text.toString())
        }

        _signup.setOnClickListener {
            val eIntent = Intent(this@LoginPage, SignUp::class.java)
            startActivity(eIntent)
        }
    }

    fun readData(db: FirebaseFirestore , Email : String , Password : String){
        db.collection("dbUser").get().addOnSuccessListener { result ->
            for (document in result){
                if(Email == document.data.get("email") && Email == "admin" && Password == document.data.get("password") && Password == "admin" ){
                    val sendIntent = Intent(this@LoginPage, AdminActivity::class.java).apply {
                        putExtra("dataEmail", Email)
                    }
                    startActivity(sendIntent)
                }
                else if (Email == document.data.get("email") && Password == document.data.get("password")){
                    val sendIntent = Intent(this@LoginPage, MainActivity2::class.java).apply {
                        putExtra("dataEmail", Email)
                    }
                    startActivity(sendIntent)
                }
            }
        }
    }
    override fun onBackPressed() {
    }
}