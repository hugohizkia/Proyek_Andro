package com.example.project_andro

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*


private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"
private lateinit var hit : String
private lateinit var Temp : String

class Reservasi : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Temp = arguments?.getString("data").toString()
        val db = FirebaseFirestore.getInstance()

        var _button = view.findViewById<Button>(R.id.btn_L)
        var _button1 = view.findViewById<Button>(R.id.btn_D)

        val myCalender = Calendar.getInstance()
        val datePicker = DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
            myCalender.set(Calendar.YEAR , year)
            myCalender.set(Calendar.MONTH , month)
            myCalender.set(Calendar.DAY_OF_MONTH , dayOfMonth)
            if (hit == "L"){
                Update(myCalender)
            }
            else if (hit == "D"){
                Update1(myCalender)
            }
        }

        _button.setOnClickListener {
            DatePickerDialog(requireContext(), datePicker, myCalender.get(Calendar.YEAR) , myCalender.get(Calendar.MONTH), myCalender.get(Calendar.DAY_OF_MONTH)).show()
            hit = "L"
        }

        _button1.setOnClickListener {
            DatePickerDialog(requireContext(), datePicker, myCalender.get(Calendar.YEAR) , myCalender.get(Calendar.MONTH), myCalender.get(Calendar.DAY_OF_MONTH)).show()
            hit = "D"
        }
    }

    fun Update(myCalendar: Calendar){
        val myFormat = "dd--MM-yyyy"
        val sdf = SimpleDateFormat(myFormat, Locale.UK)
        val mBundle = Bundle()
        mBundle.putString("data", Temp)
        mBundle.putString("data1", sdf.format(myCalendar.time))
        val mLunch = Lunch()
        mLunch.arguments = mBundle
        val mFragmentManager = parentFragmentManager
        mFragmentManager.beginTransaction().apply {
            replace(R.id.frame_layout, mLunch, Lunch::class. java.simpleName)
            addToBackStack(null)
            commit()
        }
    }

    fun Update1(myCalendar: Calendar){
        val myFormat = "dd--MM-yyyy"
        val sdf = SimpleDateFormat(myFormat, Locale.UK)
        val mBundle = Bundle()
        mBundle.putString("data", Temp)
        mBundle.putString("data1", sdf.format(myCalendar.time))
        val mDinner = Dinner()
        mDinner.arguments = mBundle
        val mFragmentManager = parentFragmentManager
        mFragmentManager.beginTransaction().apply {
            replace(R.id.frame_layout, mDinner, Dinner::class. java.simpleName)
            addToBackStack(null)
            commit()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_reservasi, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Reservasi.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Reservasi().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}