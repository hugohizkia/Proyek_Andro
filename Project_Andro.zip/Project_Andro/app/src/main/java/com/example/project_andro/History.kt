package com.example.project_andro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class History : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val db = FirebaseFirestore.getInstance()
        var data = mutableListOf<String>()
        val _lvData = findViewById<ListView>(R.id.lvData)
        val data1= intent.getStringExtra("data1")
        val _back = findViewById<Button>(R.id.buttonback)

        val sdf = SimpleDateFormat("HH")
        val currentHour = sdf.format(Date())

        val lvadapter : ArrayAdapter<String> = ArrayAdapter(
            this ,
            android.R.layout.simple_list_item_1,
            data
        )

        _back.setOnClickListener {
            val sendIntent = Intent(this@History, MainActivity2::class.java).apply {
                putExtra("data_no", "no1")
                putExtra("dataEmail", data1)
            }
            startActivity(sendIntent)
        }

        db.collection("dbDinner").get().addOnSuccessListener { result ->
            for (document in result){
                if (data1.toString() == document.data.get("email")){
                    var d = "Dinner : " + "\n" + "Table :" + document.data.get("id_meja").toString() + "\n" + "Tanggal:" + document.data.get("tanggal").toString() + "\n" + "Email User :" + document.data.get("email").toString() + "\n" + "Nama User :" +document.data.get("nama").toString() + "\n"+ "No Telp User :" +document.data.get("notelp").toString()
                    data.add(d)
                }
            }
            _lvData.adapter = lvadapter
        }

        db.collection("dbLunch").get().addOnSuccessListener { result ->
            for (document in result){
                if (data1.toString() == document.data.get("email")){
                    var d = "Lunch : " + "\n" + "Table :" + document.data.get("id_meja").toString() + "\n" + "Tanggal:" + document.data.get("tanggal").toString() + "\n" + "Email User :" + document.data.get("email").toString() + "\n" + "Nama User :" +document.data.get("nama").toString() + "\n"+ "No Telp User :" +document.data.get("notelp").toString()
                    data.add(d)
                }
            }
            _lvData.adapter = lvadapter
        }

    }
}