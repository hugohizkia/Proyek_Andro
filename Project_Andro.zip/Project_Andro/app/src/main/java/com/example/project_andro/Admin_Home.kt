package com.example.project_andro

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"


/**
 * A simple [Fragment] subclass.
 * Use the [Admin_Home.newInstance] factory method to
 * create an instance of this fragment.
 */
class Admin_Home : Fragment() {
    // TODO: Rename and change types of parameters
    private var param1: String? = null
    private var param2: String? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val db = FirebaseFirestore.getInstance()
        var data = mutableListOf<String>()
        val _lvData = view.findViewById<ListView>(R.id.lvData)
        val logout = view.findViewById<Button>(R.id.admin_logout)
        val _textview = view.findViewById<TextView>(R.id.TV_admin)

        val sdf = SimpleDateFormat("HH")
        val currentHour = sdf.format(Date())

        val sdf1 = SimpleDateFormat("dd--MM-yyyy")
        val currentDate = sdf1.format(Date())

        if (currentHour.toInt() > 15){
            _textview.setText("Data Dinner Reservation for today")
            db.collection("dbDinner").get().addOnSuccessListener { result ->
                for (document in result){
                    if (currentDate == document.data.get("tanggal")){
                        var d = "Table :" + document.data.get("id_meja").toString() + "\n" + "Tanggal :" + document.data.get("tanggal").toString() + "\n" + "Email User :" + document.data.get("email").toString() + "\n" + "Nama User :" +document.data.get("nama").toString() + "\n"+ "No Telp User :" +document.data.get("notelp").toString()
                        data.add(d)
                    }

                }
                val lvadapter : ArrayAdapter<String> = ArrayAdapter(
                    this.requireContext() ,
                    android.R.layout.simple_list_item_1,
                    data
                )
                _lvData.adapter = lvadapter

            }
        }
        else {
            _textview.setText("Data Lunch Reservation for today")
            db.collection("dbLunch").get().addOnSuccessListener { result ->
                for (document in result){
                    if (currentDate == document.data.get("tanggal")){
                        var d = "Table :" + document.data.get("id_meja").toString() + "\n" + "Tanggal :" + document.data.get("tanggal").toString() + "\n" + "Email User :" + document.data.get("email").toString() + "\n" + "Nama User :" +document.data.get("nama").toString() + "\n"+ "No Telp User :" +document.data.get("notelp").toString()
                        data.add(d)
                    }
                }
                val lvadapter : ArrayAdapter<String> = ArrayAdapter(
                    this.requireContext() ,
                    android.R.layout.simple_list_item_1,
                    data
                )
                _lvData.adapter = lvadapter
            }
        }

        logout.setOnClickListener {
            val intent = Intent (this@Admin_Home.requireContext() , LoginPage::class.java).apply {
            }
            startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_admin__home, container, false)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment Admin_Home.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Admin_Home().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}