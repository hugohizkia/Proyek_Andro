package com.example.project_andro

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.firestore.FirebaseFirestore

// TODO: Rename parameter arguments, choose names that match

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

class Profile : Fragment() {
    private var param1: String? = null
    private var param2: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val db = FirebaseFirestore.getInstance()
        val Temp = arguments?.getString("data").toString()

        var ND = view.findViewById<TextView>(R.id.ND_TV)
        var NB = view.findViewById<TextView>(R.id.NB_TV)
        var NT = view.findViewById<TextView>(R.id.NT_TV)
        var E = view.findViewById<TextView>(R.id.E_TV)

        var B = view.findViewById<FloatingActionButton>(R.id.Del_btn)
        var B1 = view.findViewById<FloatingActionButton>(R.id.edit_btn)
        var B2 = view.findViewById<Button>(R.id.history)
        var _logout = view.findViewById<Button>(R.id.logout)

        _logout.setOnClickListener {
            val intent = Intent (this@Profile.requireContext() , LoginPage::class.java).apply {
                putExtra("data1", Temp)
            }
            startActivity(intent)
        }

        B.setOnClickListener {
            val intent = Intent (this@Profile.requireContext() , ConfirmDeleteAcc::class.java).apply {
                putExtra("data1", Temp)
            }
            startActivity(intent)
        }

        B1.setOnClickListener {
            val intent = Intent (this@Profile.requireContext() , EditProfile::class.java).apply {
                putExtra("data1", Temp)
            }
            startActivity(intent)
        }

        B2.setOnClickListener {
            val intent = Intent (this@Profile.requireContext() , History::class.java).apply {
                putExtra("data1", Temp)
            }
            startActivity(intent)
        }

        db.collection("dbUser").get().addOnSuccessListener { result ->
            for (document in result){
                if (Temp == document.data.get("email")){
                    ND.setText(document.data.get("namad").toString())
                    NB.setText(document.data.get("namab").toString())
                    NT.setText(document.data.get("notelp").toString())
                    E.setText(document.data.get("email").toString())
                }
            }
        }

        //readData(db , Temp)
    }

//    fun readData(db: FirebaseFirestore , Email : String){
//        db.collection("dbUser").get().addOnSuccessListener { result ->
//            for (document in result){
//                if (Email == document.data.get("email")){
//
//                }
//            }
//        }
//    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
            Profile().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, param1)
                    putString(ARG_PARAM2, param2)
                }
            }
    }
}