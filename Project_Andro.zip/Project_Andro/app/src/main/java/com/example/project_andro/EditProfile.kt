package com.example.project_andro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.firestore.FirebaseFirestore

class EditProfile : AppCompatActivity() {
    lateinit var NamaD: EditText
    lateinit var NamaB: EditText
    lateinit var NoTelp: EditText
    lateinit var Email: EditText
    lateinit var Password: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_profile)

        val _editprof = findViewById<Button>(R.id.btn_EP)
        val _back = findViewById<Button>(R.id.buttonback)

        val db = FirebaseFirestore.getInstance()
        val data1= intent.getStringExtra("data1")

        NamaD = findViewById<EditText>(R.id.NamaDepanET)
        NamaB = findViewById<EditText>(R.id.NamaBelakangET)
        NoTelp = findViewById<EditText>(R.id.NoTelpET)
        Password = findViewById<EditText>(R.id.PasswordET)

        _editprof.setOnClickListener {
            TambahData(db, NamaD.text.toString(), NamaB.text.toString(), NoTelp.text.toString(), data1.toString() ,Password.text.toString())
        }

        _back.setOnClickListener {
            val sendIntent = Intent(this@EditProfile, MainActivity2::class.java).apply {
                putExtra("data_no", "no1")
                putExtra("dataEmail", data1)
            }
            startActivity(sendIntent)
        }

    }

    fun TambahData(db: FirebaseFirestore, namaDepan: String, namaBelakang: String, notelp: String, email: String, password:String){

        val namaBaru = datalogin(namaDepan, namaBelakang, notelp, email, password)
        db.collection("dbUser").document(email).set(namaBaru).addOnSuccessListener {
            NamaD.setText("")
            NamaB.setText("")
            NoTelp.setText("")
            Email.setText("")
            Password.setText("")
            Log.d("firebase22", "Simpan data berhasil")
            val sendIntent = Intent(this@EditProfile, MainActivity2::class.java).apply {
                putExtra("data_no", "no1")
                putExtra("dataEmail", email)
            }
            startActivity(sendIntent)
        }.addOnFailureListener {
            Log.d("firebase22", it.message.toString())
        }
    }
}