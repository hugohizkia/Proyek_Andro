package com.example.project_andro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import com.google.firebase.firestore.FirebaseFirestore

class CancelLunch : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cancel_lunch)

        val data1= intent.getStringExtra("data1")
        val data2 = intent.getStringExtra("data2")
        val data3 = intent.getStringExtra("data3")

        var _btnyes = findViewById<Button>(R.id.btn_yes1)
        var _btnno = findViewById<Button>(R.id.btn_no1)

        val db = FirebaseFirestore.getInstance()

        _btnyes.setOnClickListener {
            var count = 1
            if (count == 1){
                db.collection("dbLunch").get().addOnSuccessListener { result ->
                    for (document in result){
                        if (data2.toString() == document.data.get("id_meja") && data3.toString() == document.data.get("tanggal") && data1.toString() == document.data.get("email")){
                            db.collection("dbLunch").document(document.data.get("id").toString()).delete()
                        }
                    }
                }
                val sendIntent = Intent(this@CancelLunch, MainActivity2::class.java).apply {
                    putExtra("data_no", "no")
                    putExtra("dataEmail", data1)
                }
                startActivity(sendIntent)
            }
        }

        _btnno.setOnClickListener {
            val sendIntent = Intent(this@CancelLunch, MainActivity2::class.java).apply {
                putExtra("data_no", "no")
                putExtra("dataEmail", data1)
            }
            startActivity(sendIntent)
        }
    }
}