package com.example.project_andro

data class datareservasi(
    var id : String,
    var id_meja : String,
    var tanggal : String,
    var nama: String,
    var notelp: String,
    var email: String
)
