package com.example.project_andro

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.example.project_andro.databinding.ActivityAdminBinding

class AdminActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAdminBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        replaceFragment(Admin_Home())


        binding.bottomNavigationView1.setOnItemSelectedListener {
            when(it.itemId){
                R.id.Home -> replaceFragment(Admin_Home())
                R.id.UR -> replaceFragment(Admin_Recommend())
                else -> {
                }
            }
            true
        }
    }

    private fun replaceFragment(fragment : Fragment){
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()

//        val _email = intent.getStringExtra("dataEmail")
//        val mBundle = Bundle()
//        mBundle.putString("data", _email)
//        fragment.arguments = mBundle
        fragmentTransaction.replace(R.id.frame_layout,fragment)
        fragmentTransaction.commit()
    }

    override fun onBackPressed() {
    }
}