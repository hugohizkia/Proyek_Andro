package com.example.project_andro

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import com.google.firebase.firestore.FirebaseFirestore

class ConfirmLunch : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm_lunch)

        val db = FirebaseFirestore.getInstance()

        val data1= intent.getStringExtra("data1")
        val data2 = intent.getStringExtra("data2")
        val data3 = intent.getStringExtra("data3")

        var ND = findViewById<TextView>(R.id.textViewNamaD)
        var NB = findViewById<TextView>(R.id.textViewNamaB)
        var NT = findViewById<TextView>(R.id.textViewNoTelp)
        var E = findViewById<TextView>(R.id.textViewEmail)
        var M = findViewById<TextView>(R.id.textViewMeja)
        var YES = findViewById<Button>(R.id.yes)
        var NO = findViewById<Button>(R.id.no)

        var id = "1"
        var cek = 0
        var intid = 0
        var hasil = 0


        M.setText(data2.toString())
        db.collection("dbUser").get().addOnSuccessListener { result ->
            for (document in result){
                if (data1 == document.data.get("email")){
                    ND.setText(document.data.get("namad").toString())
                    NB.setText(document.data.get("namab").toString())
                    NT.setText(document.data.get("notelp").toString())
                    E.setText(document.data.get("email").toString())
                }
            }
        }

        db.collection("dbLunch").get().addOnSuccessListener { result ->
            for (document in result){
                id = document.data.get("id").toString()

                intid = id.toInt()+1
                if (cek < intid){
                    if (hasil < intid){
                        hasil = intid
                    }

                }
                else if (cek > intid){
                    cek = cek + 1
                    if (hasil < cek){
                        hasil = cek
                    }
                }
                cek = id.toInt()
                id = hasil.toString()
            }
        }

        NO.setOnClickListener {
            val sendIntent = Intent(this@ConfirmLunch, MainActivity2::class.java).apply {
                putExtra("data_no", "no")
                putExtra("dataEmail", data1)
            }
            startActivity(sendIntent)
        }

        YES.setOnClickListener {
            val namaBaru = datareservasi(id, M.text.toString(),data3.toString() , ND.text.toString()+" "+NB.text.toString(), NT.text.toString(), E.text.toString())
            db.collection("dbLunch").document(id).set(namaBaru).addOnSuccessListener {
                Log.d("firebase22", "Simpan data berhasil")
            }.addOnFailureListener {
                Log.d("firebase22", it.message.toString())

            }
            val sendIntent = Intent(this@ConfirmLunch, MainActivity2::class.java).apply {
                putExtra("data_no", "no")
                putExtra("dataEmail", E.text.toString())
            }
            startActivity(sendIntent)
        }
    }

}